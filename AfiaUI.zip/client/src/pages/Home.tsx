import { useWorkspace } from "@/contexts/WorkspaceContext";
import { Button } from "@/components/ui/button";
import { Monogram, RiskBadge, StatusChip, AiTag } from "@/components/primitives";
import { appointments, inboxItems } from "@/data/workspace";
import { patients } from "@/data/patients";
import type { Patient } from "@/data/types";
import { fmtTime, fmtRelative } from "@/data/workspace";
import { useLocation } from "wouter";
import { Calendar, Inbox, AlertCircle, TrendingUp } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const { openInspector, pushRecent } = useWorkspace();

  const criticalPatients = patients.filter((p: Patient) => p.risk === "critical").slice(0, 5);
  const todayAppts = appointments.filter((a) => a.status !== "cancelled").slice(0, 4);
  const unreadInbox = inboxItems.filter((i) => i.unread).slice(0, 4);

  const handlePatientClick = (id: string) => {
    pushRecent(id);
    openInspector(id);
    setLocation(`/patients/${id}`);
  };

  return (
    <div className="h-full overflow-auto">
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-semibold tracking-tight mb-1">
            Welcome back
          </h1>
          <p className="text-muted-foreground">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>

        {/* Grid: Critical, Inbox, Schedule, Insights */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Critical Patients */}
          <div className="border border-hairline rounded-lg bg-surface p-4">
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="size-5 text-destructive" />
              <h2 className="font-semibold">Critical Attention</h2>
              <span className="ml-auto text-xs text-muted-foreground">
                {criticalPatients.length} patients
              </span>
            </div>
            <div className="space-y-2">
              {criticalPatients.map((p: Patient) => (
                <button
                  key={p.id}
                  onClick={() => handlePatientClick(p.id)}
                  className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-elevated transition-colors text-left"
                >
                  <Monogram name={p.name} size={24} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      {p.name}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      {p.condition}
                    </div>
                  </div>
                  <RiskBadge risk={p.risk} showLabel={false} />
                </button>
              ))}
            </div>
          </div>

          {/* Unread Inbox */}
          <div className="border border-hairline rounded-lg bg-surface p-4">
            <div className="flex items-center gap-2 mb-4">
              <Inbox className="size-5 text-primary" />
              <h2 className="font-semibold">Inbox</h2>
              <span className="ml-auto text-xs text-muted-foreground">
                {unreadInbox.length} unread
              </span>
            </div>
            <div className="space-y-2">
              {unreadInbox.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setLocation("/inbox")}
                  className="w-full text-left p-2 rounded-md hover:bg-elevated transition-colors"
                >
                  <div className="text-sm font-medium line-clamp-1">
                    {item.title}
                  </div>
                  <div className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
                    {item.preview}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Today's Schedule */}
          <div className="border border-hairline rounded-lg bg-surface p-4">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="size-5 text-ai" />
              <h2 className="font-semibold">Today's Schedule</h2>
              <span className="ml-auto text-xs text-muted-foreground">
                {todayAppts.length} appointments
              </span>
            </div>
            <div className="space-y-2">
              {todayAppts.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setLocation("/schedule")}
                  className="w-full text-left p-2 rounded-md hover:bg-elevated transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <div className="font-mono text-xs font-semibold text-primary">
                      {fmtTime(a.start)}
                    </div>
                    <div className="text-sm font-medium truncate">
                      {a.patientName}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {a.kind} • {a.location}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* AI Insights */}
          <div className="border border-hairline rounded-lg bg-surface p-4">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="size-5" />
              <h2 className="font-semibold">AFIA Insights</h2>
            </div>
            <div className="space-y-3">
              <div className="rounded-md border border-ai/25 bg-ai/10 p-2">
                <div className="text-xs font-semibold flex items-center gap-1">
                  <AiTag />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Two patients show early decompensation signals. Review recommended.
                </p>
              </div>
              <div className="rounded-md border border-border bg-elevated p-2">
                <div className="text-xs font-semibold">Care Gaps</div>
                <p className="text-xs text-muted-foreground mt-1">
                  5 overdue screenings across your active panel.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
