import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AiTag } from "@/components/primitives";
import { Send, Sparkles } from "lucide-react";

export default function Assistant() {
  const [messages, setMessages] = useState<
    Array<{ role: "user" | "assistant"; text: string }>
  >([
    {
      role: "assistant",
      text: "Hi! I'm AFIA, your AI healthcare assistant. Ask me about patient trends, care gaps, clinical protocols, or anything else related to your practice.",
    },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages((m) => [
      ...m,
      { role: "user", text: input },
      {
        role: "assistant",
        text: "I'm analyzing your question. In a production system, I would provide real clinical insights powered by your patient data and medical knowledge base.",
      },
    ]);
    setInput("");
  };

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-hairline px-6 py-4">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="size-5 text-ai" />
          <h1 className="text-2xl font-semibold">AFIA Assistant</h1>
        </div>
        <p className="text-sm text-muted-foreground">
          Ask questions about your patients, practice, or clinical protocols
        </p>
      </div>
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-md rounded-lg p-3 ${
                msg.role === "user"
                  ? "bg-primary text-primary-foreground"
                  : "bg-surface border border-ai/25"
              }`}
            >
              <p className="text-sm">{msg.text}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="border-t border-hairline px-6 py-4">
        <div className="flex gap-2">
          <Input
            placeholder="Ask AFIA something…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
          />
          <Button onClick={handleSend} size="icon">
            <Send className="size-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
