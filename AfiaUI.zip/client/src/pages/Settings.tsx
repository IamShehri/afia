import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { currentUser } from "@/data/clinicians";
import { Monogram } from "@/components/primitives";
import { Settings as SettingsIcon } from "lucide-react";

export default function Settings() {
  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-hairline px-6 py-4">
        <h1 className="text-2xl font-semibold mb-2">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Manage your account and preferences
        </p>
      </div>
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-2xl space-y-8">
          <div>
            <h2 className="text-lg font-semibold mb-4">Profile</h2>
            <div className="flex items-center gap-4 p-4 border border-hairline rounded-lg bg-surface">
              <Monogram name={currentUser.name} size={48} />
              <div>
                <div className="font-semibold">{currentUser.name}</div>
                <div className="text-sm text-muted-foreground">
                  {currentUser.role} • {currentUser.specialty}
                </div>
              </div>
            </div>
          </div>
          <div>
            <h2 className="text-lg font-semibold mb-4">Preferences</h2>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium">Notifications</label>
                <p className="text-xs text-muted-foreground mt-1">
                  Receive alerts for critical patients
                </p>
              </div>
              <div>
                <label className="text-sm font-medium">Theme</label>
                <p className="text-xs text-muted-foreground mt-1">
                  Dark mode is currently enabled
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
