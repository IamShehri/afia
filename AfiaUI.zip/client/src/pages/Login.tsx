import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { AfiaWordmark } from "@/components/brand/AfiaMark";
import { ArrowRight } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background bg-dotgrid px-4">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <AfiaWordmark className="text-2xl justify-center mb-4" />
          <h1 className="text-3xl font-semibold tracking-tight mb-2">
            Welcome to AFIA
          </h1>
          <p className="text-muted-foreground">
            The AI-native healthcare operating system
          </p>
        </div>

        <div className="space-y-3">
          <Button
            onClick={() => setLocation("/")}
            className="w-full press"
            size="lg"
          >
            Continue as Demo User
            <ArrowRight className="size-4" />
          </Button>
          <p className="text-xs text-center text-muted-foreground">
            Demo credentials: any email / password
          </p>
        </div>
      </div>
    </div>
  );
}
