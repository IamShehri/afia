export default function PatientDetail({ id }: { id: string }) {
  return <div className="p-6"><h1 className="text-2xl font-semibold">Patient: {id}</h1></div>;
}
