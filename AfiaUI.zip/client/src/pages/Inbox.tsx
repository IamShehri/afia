import { inboxItems } from "@/data/workspace";
import { fmtRelative } from "@/data/workspace";
import { RiskBadge } from "@/components/primitives";
import { AlertCircle, Mail } from "lucide-react";

export default function Inbox() {
  const unread = inboxItems.filter((i) => i.unread);
  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-hairline px-6 py-4">
        <h1 className="text-2xl font-semibold mb-2">Inbox</h1>
        <p className="text-sm text-muted-foreground">{unread.length} unread</p>
      </div>
      <div className="flex-1 overflow-auto">
        <div className="divide-y divide-hairline">
          {inboxItems.map((item) => (
            <div
              key={item.id}
              className={`px-6 py-4 hover:bg-surface transition-colors cursor-pointer ${
                item.unread ? "bg-surface/50" : ""
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 mt-1">
                  {item.kind === "result" && (
                    <AlertCircle className="size-5 text-destructive" />
                  )}
                  {item.kind === "ai" && (
                    <Mail className="size-5 text-ai" />
                  )}
                  {!["result", "ai"].includes(item.kind) && (
                    <Mail className="size-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-muted-foreground mt-1 line-clamp-1">
                    {item.preview}
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <RiskBadge risk={item.priority} showLabel={false} />
                    <span className="text-xs text-muted-foreground">
                      {fmtRelative(item.at)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
