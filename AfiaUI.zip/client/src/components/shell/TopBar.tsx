import { useWorkspace } from "@/contexts/WorkspaceContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Kbd } from "@/components/primitives";
import { currentUser } from "@/data/clinicians";
import { Monogram } from "@/components/primitives";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, Moon, Sun, LogOut, Settings } from "lucide-react";
import { useLocation } from "wouter";

export function TopBar() {
  const { setPaletteOpen } = useWorkspace();
  const { theme, toggleTheme } = useTheme();
  const [, setLocation] = useLocation();

  return (
    <div className="flex h-12 items-center justify-between gap-4 border-b border-hairline bg-background px-4">
      {/* Left: search trigger */}
      <button
        onClick={() => setPaletteOpen(true)}
        className="flex h-8 flex-1 max-w-sm items-center gap-2 rounded-md border border-hairline bg-surface px-3 text-sm text-muted-foreground transition-colors hover:bg-surface hover:border-hairline-strong press"
      >
        <Search className="size-4 opacity-60" />
        <span className="hidden sm:inline">Search patients, actions…</span>
        <span className="sm:hidden">Search…</span>
        <Kbd className="ml-auto">⌘K</Kbd>
      </button>

      {/* Right: theme + user menu */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => toggleTheme?.()}
          title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
        >
          {theme === "dark" ? (
            <Sun className="size-4" />
          ) : (
            <Moon className="size-4" />
          )}
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon-sm" className="rounded-full">
              <Monogram name={currentUser.name} hue={currentUser.hue} size={20} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <div className="flex items-center gap-3 px-3 py-2">
              <Monogram name={currentUser.name} hue={currentUser.hue} size={32} />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">
                  {currentUser.name}
                </div>
                <div className="text-xs text-muted-foreground truncate">
                  {currentUser.role}
                </div>
              </div>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => setLocation("/settings")}
              className="cursor-pointer"
            >
              <Settings className="size-4" />
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer text-destructive">
              <LogOut className="size-4" />
              <span>Sign out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
