import { Button } from "@/components/ui/button";
import { SectionLabel } from "@/components/primitives";
import { ChevronLeft, Filter } from "lucide-react";

export function SecondaryBar({
  collapsed,
  onToggleCollapse,
}: {
  collapsed: boolean;
  onToggleCollapse: () => void;
}) {
  if (collapsed) {
    return (
      <div className="flex w-10 flex-col items-center border-r border-hairline bg-rail py-2">
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={onToggleCollapse}
          title="Show context sidebar"
        >
          <ChevronLeft className="size-4 rotate-180" />
        </Button>
      </div>
    );
  }

  return (
    <div className="w-56 border-r border-hairline bg-surface overflow-y-auto flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 border-b border-hairline px-3 py-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Filter className="size-4" />
          Context
        </div>
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={onToggleCollapse}
          title="Hide context sidebar"
        >
          <ChevronLeft className="size-4" />
        </Button>
      </div>

      {/* Content area — placeholder for module-specific content */}
      <div className="flex-1 space-y-4 p-3">
        <div>
          <SectionLabel>Filters</SectionLabel>
          <div className="mt-2 space-y-2 text-xs text-muted-foreground">
            <p>Module-specific filters will appear here.</p>
          </div>
        </div>

        <div>
          <SectionLabel>Saved Views</SectionLabel>
          <div className="mt-2 space-y-2 text-xs text-muted-foreground">
            <p>Your saved views will appear here.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
