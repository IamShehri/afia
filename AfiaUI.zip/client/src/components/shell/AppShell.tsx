import { useState } from "react";
import { TopBar } from "./TopBar";
import { PrimaryRail } from "./PrimaryRail";
import { SecondaryBar } from "./SecondaryBar";
import { Inspector } from "./Inspector";
import { StatusBar } from "./StatusBar";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: React.ReactNode }) {
  const [secondaryCollapsed, setSecondaryCollapsed] = useState(false);

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Top command bar */}
      <TopBar />

      {/* Main workspace grid */}
      <div className="flex flex-1 overflow-hidden">
        {/* Primary rail */}
        <PrimaryRail />

        {/* Secondary sidebar (context-dependent) */}
        <SecondaryBar
          collapsed={secondaryCollapsed}
          onToggleCollapse={() => setSecondaryCollapsed(!secondaryCollapsed)}
        />

        {/* Workspace (main content area) */}
        <div className="flex-1 overflow-auto">
          <div className="h-full">{children}</div>
        </div>

        {/* Inspector slide-over (right) */}
        <Inspector />
      </div>

      {/* Status bar */}
      <StatusBar />
    </div>
  );
}
