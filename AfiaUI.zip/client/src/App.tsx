import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { WorkspaceProvider } from "./contexts/WorkspaceContext";
import { CommandPalette } from "./components/command/CommandPalette";
import { AppShell } from "./components/shell/AppShell";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Patients from "./pages/Patients";
import PatientDetail from "./pages/PatientDetail";
import Schedule from "./pages/Schedule";
import Inbox from "./pages/Inbox";
import Assistant from "./pages/Assistant";
import Insights from "./pages/Insights";
import Settings from "./pages/Settings";

function Shell({ children }: { children: React.ReactNode }) {
  return <AppShell>{children}</AppShell>;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />

      <Route path="/">{() => <Shell><Home /></Shell>}</Route>
      <Route path="/patients">{() => <Shell><Patients /></Shell>}</Route>
      <Route path="/patients/:id">
        {(params) => <Shell><PatientDetail id={params.id} /></Shell>}
      </Route>
      <Route path="/schedule">{() => <Shell><Schedule /></Shell>}</Route>
      <Route path="/inbox">{() => <Shell><Inbox /></Shell>}</Route>
      <Route path="/assistant">{() => <Shell><Assistant /></Shell>}</Route>
      <Route path="/insights">{() => <Shell><Insights /></Shell>}</Route>
      <Route path="/settings">{() => <Shell><Settings /></Shell>}</Route>
      <Route path="/settings/:section">
        {(params) => <Shell><Settings /></Shell>}
      </Route>

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider delayDuration={200} skipDelayDuration={0}>
          <WorkspaceProvider>
            <Toaster position="bottom-right" />
            <CommandPalette />
            <Router />
          </WorkspaceProvider>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
